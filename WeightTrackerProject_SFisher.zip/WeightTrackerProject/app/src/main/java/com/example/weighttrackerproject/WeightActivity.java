package com.example.weighttrackerproject;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.database.Cursor;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AlertDialog;
import android.text.InputType;
import android.content.Intent;

public class WeightActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private int userId;
    private EditText weightInput;
    private EditText dateInput;
    private Button addWeightButton;
    private EditText goalWeightInput;
    private Button addGoalButton;
    private TextView dateRow1, dateRow2, dateRow3;
    private TextView weightRow1, weightRow2, weightRow3;
    private Button deleteButton1, deleteButton2, deleteButton3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight);
        databaseHelper = new DatabaseHelper(this);

        String username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        userId = databaseHelper.getUserId(username);

        if (userId == -1) {
            Toast.makeText(this, "User account not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        weightInput = findViewById(R.id.editTextNumberDecimal);
        dateInput = findViewById(R.id.editTextText2);
        addWeightButton = findViewById(R.id.button6);
        goalWeightInput = findViewById(R.id.editTextNumberDecimal2);
        addGoalButton = findViewById(R.id.button7);

        // Connect the existing weight history rows
        dateRow1 = findViewById(R.id.textView6);
        weightRow1 = findViewById(R.id.textView7);
        deleteButton1 = findViewById(R.id.button3);

        dateRow2 = findViewById(R.id.textView8);
        weightRow2 = findViewById(R.id.textView9);
        deleteButton2 = findViewById(R.id.button4);

        dateRow3 = findViewById(R.id.textView11);
        weightRow3 = findViewById(R.id.textView10);
        deleteButton3 = findViewById(R.id.button5);

        displayWeights();

        // Open SMS notification settings when the heading is tapped
        TextView notificationLink = findViewById(R.id.textView);

        notificationLink.setOnClickListener(v -> {
            Intent intent = new Intent(
                    WeightActivity.this,
                    SMSNotifications.class
            );
            startActivity(intent);
        });

        addWeightButton.setOnClickListener(v -> {

            String weightText = weightInput.getText().toString().trim();
            String date = dateInput.getText().toString().trim();

            if (weightText.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please enter weight and date",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double weight = Double.parseDouble(weightText);

                if (!Double.isFinite(weight) || weight <= 0) {
                    Toast.makeText(this, "Enter a valid weight",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean success = databaseHelper.addWeight(userId, weight, date);

                if (success) {
                    Toast.makeText(this, "Weight saved!",
                            Toast.LENGTH_SHORT).show();

                    weightInput.setText("");
                    dateInput.setText("");
                    displayWeights();

                    // Check whether the user has reached their goal
                    double goalWeight = databaseHelper.getGoalWeight(userId);

                    if (goalWeight > 0 && weight <= goalWeight) {
                        new AlertDialog.Builder(this)
                                .setTitle("Congratulations!")
                                .setMessage("You have reached your goal weight!")
                                .setPositiveButton("OK", null)
                                .show();
                    }

                } else {
                    Toast.makeText(this, "Unable to save weight",
                            Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid number",
                        Toast.LENGTH_SHORT).show();
            }
        });

        addGoalButton.setOnClickListener(v -> {

            String goalText = goalWeightInput.getText().toString().trim();

            if (goalText.isEmpty()) {
                Toast.makeText(this, "Please enter a goal weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double goalWeight = Double.parseDouble(goalText);

                if (!Double.isFinite(goalWeight) || goalWeight <= 0) {
                    Toast.makeText(this, "Enter a valid goal weight",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean success = databaseHelper.saveGoal(userId, goalWeight);

                if (success) {
                    Toast.makeText(this, "Goal weight saved!",
                            Toast.LENGTH_SHORT).show();

                    goalWeightInput.setText("");

                } else {
                    Toast.makeText(this, "Unable to save goal",
                            Toast.LENGTH_SHORT).show();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid number",
                        Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void displayWeights() {

        TextView[] dateRows = {dateRow1, dateRow2, dateRow3};
        TextView[] weightRows = {weightRow1, weightRow2, weightRow3};
        Button[] deleteButtons = {
                deleteButton1, deleteButton2, deleteButton3
        };

        // Clear the example data before displaying saved records
        for (int i = 0; i < 3; i++) {
            dateRows[i].setText("");
            weightRows[i].setText("");
            weightRows[i].setOnClickListener(null);
            deleteButtons[i].setVisibility(View.INVISIBLE);
            deleteButtons[i].setOnClickListener(null);
        }

        try (Cursor cursor = databaseHelper.getWeights(userId)) {

            int row = 0;

            while (cursor.moveToNext() && row < 3) {

                int weightId = cursor.getInt(
                        cursor.getColumnIndexOrThrow("_id")
                );

                String date = cursor.getString(
                        cursor.getColumnIndexOrThrow("date")
                );

                double weight = cursor.getDouble(
                        cursor.getColumnIndexOrThrow("weight")
                );

                dateRows[row].setText(date);
                weightRows[row].setText(weight + " lbs");

                // Allow users to tap a weight to edit it
                TextView weightTextView = weightRows[row];

                weightTextView.setOnClickListener(v -> {

                    EditText editWeight = new EditText(this);
                    editWeight.setInputType(
                            InputType.TYPE_CLASS_NUMBER |
                                    InputType.TYPE_NUMBER_FLAG_DECIMAL
                    );

                    editWeight.setText(String.valueOf(weight));

                    new AlertDialog.Builder(this)
                            .setTitle("Edit Weight")
                            .setMessage("Enter your updated weight:")
                            .setView(editWeight)
                            .setPositiveButton("Save", (dialog, which) -> {

                                try {
                                    double newWeight = Double.parseDouble(
                                            editWeight.getText().toString().trim()
                                    );

                                    if (!Double.isFinite(newWeight) || newWeight <= 0) {
                                        Toast.makeText(this, "Enter a valid weight",
                                                Toast.LENGTH_SHORT).show();
                                        return;
                                    }

                                    boolean updated = databaseHelper.updateWeight(
                                            weightId, userId, newWeight
                                    );

                                    if (updated) {
                                        Toast.makeText(this, "Weight updated!",
                                                Toast.LENGTH_SHORT).show();

                                        displayWeights();
                                    } else {
                                        Toast.makeText(this, "Unable to update weight",
                                                Toast.LENGTH_SHORT).show();
                                    }

                                } catch (NumberFormatException e) {
                                    Toast.makeText(this, "Enter a valid number",
                                            Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });

                Button deleteButton = deleteButtons[row];
                deleteButton.setVisibility(View.VISIBLE);

                deleteButton.setOnClickListener(v -> {

                    boolean deleted = databaseHelper.deleteWeight(
                            weightId, userId
                    );

                    if (deleted) {
                        Toast.makeText(this, "Weight deleted",
                                Toast.LENGTH_SHORT).show();

                        displayWeights();
                    }
                });

                row++;
            }
        }
    }
}