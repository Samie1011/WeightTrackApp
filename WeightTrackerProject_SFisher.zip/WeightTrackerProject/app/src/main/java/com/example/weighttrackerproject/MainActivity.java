package com.example.weighttrackerproject;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    private EditText usernameField;
    private EditText passwordField;

    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        usernameField = findViewById(R.id.editTextText);
        passwordField = findViewById(R.id.editTextTextPassword);

        loginButton = findViewById(R.id.button);
        createAccountButton = findViewById(R.id.button2);

        databaseHelper = new DatabaseHelper(this);

        createAccountButton.setOnClickListener(v -> {

            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = databaseHelper.createAccount(username, password);

            if (success) {
                Toast.makeText(this, "Account created successfully!",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Username already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loginButton.setOnClickListener(v -> {

            String username = usernameField.getText().toString().trim();
            String password = passwordField.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean validLogin = databaseHelper.checkLogin(username, password);

            if (validLogin) {
                Toast.makeText(this, "Login successful!",
                        Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(MainActivity.this, WeightActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);

            } else {
                Toast.makeText(this, "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}