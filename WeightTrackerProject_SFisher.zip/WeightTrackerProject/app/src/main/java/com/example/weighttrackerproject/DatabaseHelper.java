package com.example.weighttrackerproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.sqlite.SQLiteConstraintException;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import android.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import android.database.Cursor;

// Your class starts here
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "password_hash TEXT NOT NULL, " +
                        "password_salt TEXT NOT NULL)";

        db.execSQL(createUsersTable);

        String createWeightsTable =
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "weight REAL NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "FOREIGN KEY(user_id) REFERENCES users(id))";

        db.execSQL(createWeightsTable);

        String createGoalsTable =
                "CREATE TABLE goals (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL UNIQUE, " +
                        "goal_weight REAL NOT NULL, " +
                        "FOREIGN KEY(user_id) REFERENCES users(id))";

        db.execSQL(createGoalsTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS goals");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");

        onCreate(db);

    }

    public boolean createAccount(String username, String password) {
        String passwordSalt = generateSalt();
        String passwordHash = hashPassword(password, passwordSalt);

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", passwordHash);
        values.put("password_salt", passwordSalt);

        try {
            long result = db.insertOrThrow("users", null, values);
            return result != -1;
        } catch (SQLiteConstraintException e) {
            return false;
        }
    }

    public static String generateSalt() {
        byte[] salt = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(salt);

        return Base64.encodeToString(salt, Base64.NO_WRAP);
    }

    public static String hashPassword(String password, String salt) {
        try {
            byte[] saltBytes = Base64.decode(salt, Base64.NO_WRAP);

            KeySpec spec = new PBEKeySpec(
                    password.toCharArray(),
                    saltBytes,
                    120000,
                    256
            );

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (Exception e) {
            throw new IllegalStateException("Unable to hash password", e);
        }
    }

    public boolean checkLogin(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT password_hash, password_salt FROM users WHERE username = ?",
                new String[]{username}
        );

        try {
            if (cursor.moveToFirst()) {

                String savedHash = cursor.getString(0);
                String savedSalt = cursor.getString(1);

                String enteredHash = hashPassword(password, savedSalt);

                return java.security.MessageDigest.isEqual(
                        Base64.decode(savedHash, Base64.NO_WRAP),
                        Base64.decode(enteredHash, Base64.NO_WRAP)
                );
            }

            return false;

        } finally {
            cursor.close();
        }
    }

    public boolean addWeight(int userId, double weight, String date) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("date", date);

        long result = db.insert("weights", null, values);

        return result != -1;
    }

    public int getUserId(String username) {

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM users WHERE username = ?",
                new String[]{username}
        );

        try {
            if (cursor.moveToFirst()) {
                return cursor.getInt(0);
            }

            return -1;

        } finally {
            cursor.close();
        }
    }

    public boolean saveGoal(int userId, double goalWeight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("goal_weight", goalWeight);

        long result = db.insertWithOnConflict(
                "goals",
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        );

        return result != -1;
    }

    public Cursor getWeights(int userId) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT id AS _id, weight, date FROM weights " +
                        "WHERE user_id = ? ORDER BY id DESC",
                new String[]{String.valueOf(userId)}
        );
    }

    public boolean deleteWeight(int weightId, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(
                "weights",
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                }
        );

        return rowsDeleted > 0;
    }

    public boolean updateWeight(int weightId, int userId, double newWeight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("weight", newWeight);

        int rowsUpdated = db.update(
                "weights",
                values,
                "id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(weightId),
                        String.valueOf(userId)
                }
        );

        return rowsUpdated > 0;
    }

    public double getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor cursor = db.rawQuery(
                "SELECT goal_weight FROM goals WHERE user_id = ?",
                new String[]{String.valueOf(userId)}
        )) {
            if (cursor.moveToFirst()) {
                return cursor.getDouble(0);
            }
        }

        return -1;
    }
}
