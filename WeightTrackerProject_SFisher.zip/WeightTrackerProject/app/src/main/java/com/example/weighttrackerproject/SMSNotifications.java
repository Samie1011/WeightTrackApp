package com.example.weighttrackerproject;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SMSNotifications extends AppCompatActivity {

    private Button smsButton, reminderButton, tipsButton;
    private Button enableAllButton, unsubscribeButton;

    private SharedPreferences preferences;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            Toast.makeText(this,
                                    "SMS permission granted",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this,
                                    "SMS permission denied. Other features still work.",
                                    Toast.LENGTH_LONG).show();
                        }

                        updateButtons();
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsnotifications);

        preferences = getSharedPreferences(
                "WeightTrackerNotifications", MODE_PRIVATE
        );

        smsButton = findViewById(R.id.button13);
        reminderButton = findViewById(R.id.button8);
        tipsButton = findViewById(R.id.button9);
        enableAllButton = findViewById(R.id.button11);
        unsubscribeButton = findViewById(R.id.button12);

        Button progressButton = findViewById(R.id.button10);

        smsButton.setOnClickListener(v -> {
            boolean enabled = !preferences.getBoolean("sms", false);
            preferences.edit().putBoolean("sms", enabled).apply();

            if (enabled) {
                requestSmsPermission();
            }

            updateButtons();
        });

        reminderButton.setOnClickListener(v -> togglePreference("reminders"));
        tipsButton.setOnClickListener(v -> togglePreference("tips"));
        progressButton.setOnClickListener(v -> togglePreference("progress"));

        enableAllButton.setOnClickListener(v -> {
            preferences.edit()
                    .putBoolean("sms", true)
                    .putBoolean("reminders", true)
                    .putBoolean("tips", true)
                    .putBoolean("progress", true)
                    .apply();

            requestSmsPermission();
            updateButtons();
        });

        unsubscribeButton.setOnClickListener(v -> {
            preferences.edit()
                    .putBoolean("sms", false)
                    .putBoolean("reminders", false)
                    .putBoolean("tips", false)
                    .putBoolean("progress", false)
                    .apply();

            updateButtons();

            Toast.makeText(this,
                    "Notifications disabled",
                    Toast.LENGTH_SHORT).show();
        });

        updateButtons();
    }

    private void togglePreference(String key) {
        boolean enabled = !preferences.getBoolean(key, false);
        preferences.edit().putBoolean(key, enabled).apply();
        updateButtons();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void updateButtons() {
        updateButton(smsButton, preferences.getBoolean("sms", false));
        updateButton(reminderButton, preferences.getBoolean("reminders", false));
        updateButton(tipsButton, preferences.getBoolean("tips", false));

        Button progressButton = findViewById(R.id.button10);
        updateButton(progressButton, preferences.getBoolean("progress", false));
    }

    private void updateButton(Button button, boolean enabled) {
        button.setText(enabled ? "On" : "Off");

        int color = enabled ? 0xFFF391C7 : 0xFFC3EADA;

        button.setBackgroundTintList(
                ColorStateList.valueOf(color)
        );

        button.setTextColor(0xFF000000);
    }
}